<?php get_header(); ?>

			<?php if ( have_posts() ) : ?>

				<?php while ( have_posts() ) : the_post(); ?>
						
							<section>
								<div class="image-container">
									<div class="background-image" style="background-image:url(<?php the_post_thumbnail_url()?>);">										
									</div>
								</div>
								<div class="title-container">
									<h1><?php the_title() ?></h1>									
								</div>								
								<div class="container">
									<div class="align-center"><p style="color:#616161; text-transform:uppercase;" class="p-small"><?php the_date(); ?></p></div>
									<div class="post-content">
									<?php the_content(); ?>
									</div>
								</div>
							</section>
													
				<?php endwhile; ?>

			<?php else :  ?>

				<article>
					<h1>Nenhuma informação na página</h1>
				</article>

			<?php endif; ?>

<?php get_footer(); ?>
