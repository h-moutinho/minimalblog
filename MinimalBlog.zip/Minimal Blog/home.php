<!-- INCLUDE HEADER -->

<?php get_header();?>

<!-- BLOCK BLOG -->
<section class="container">
	<h1 class="page-title">
		<?php 
			$blog_title = get_bloginfo('name');
			echo $blog_title;
		?>
	</h1>
	<p class="page-desc p-regular">
		<?php 
			$blog_desc = get_bloginfo('description');
			echo $blog_desc;
		?>
	</p>	
</section>

<section>
	<div class="container">
<?php
	// and now the loop
		
	if($wp_query->have_posts()):
	while($wp_query->have_posts()): the_post(); 
?>

<!-- now you can build your page -->
               		
<article class="blog-box">
	<div class="div-blog-thumb">
		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
	</div>
	<div class="div-title-ex">
		<div class="div-title-ex-son">
			<a href="<?php the_permalink(); ?>"><h1><?php the_title() ?></h1></a>
			<a href="<?php the_permalink(); ?>"><h2 class="p-regular"><?php echo get_the_excerpt(); ?></h2></a>
		</div>
	</div>
</article>
        <?php endwhile; ?>
        <!-- navigation code goes here -->
<?php endif; ?>
 
<!-- 	Subscribe	-->
 	
 		<div class="subscribe-blog">
 			<div class="six columns">
 				<h1>Get more insights.</h1>
 				<p class="p-regular">Straight to your inbox.</p>
 			</div>
 			<div class="six columns">
 				<form action="" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
					<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL" placeholder="your best email">
					<input type="text" value="" name="FNAME" class="" id="mce-FNAME" placeholder="your first name">
					<div id="mce-responses" class="clear">
						<div class="response" id="mce-error-response" style="display:none"></div>
						<div class="response" id="mce-success-response" style="display:none"></div>
					</div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
					<div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_4cd216682ded9971ddd0f892e_097288f886" tabindex="-1" value=""><br></div>
					<div class="clear"><input id="btn-subscribe" class="button" type="submit" value="Subscribe me now" name="subscribe" id="mc-embedded-subscribe" class="button"><br></div>
				</form>
					<script type="text/javascript" src="//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js"></script><script type="text/javascript">(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]="EMAIL";ftypes[0]="email";fnames[1]="FNAME";ftypes[1]='text';}(jQuery));var $mcj = jQuery.noConflict(true);</script>
 			</div>
 		</div>
 		
	</div>
</section>
<!-- INCLUDE FOOTER -->

<?php get_footer();?>