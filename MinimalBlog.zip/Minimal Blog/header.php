<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<meta name="viewport" content="width=device-width" />
		<title><?php wp_title(); ?></title>
		<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,900" rel="stylesheet">
		<link rel='stylesheet' href="<?php echo get_stylesheet_directory_uri(); ?>/style.css"/>
		
		<!-- BLOG FONT -->
		<?php 
		if (is_single()) {
		echo '<link href="https://fonts.googleapis.com/css?family=Merriweather" rel="stylesheet">';
		} else {echo '';}
		?>
		<!-- GOOGLE ANALYTICS -->
		
		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script async src="https://www.googletagmanager.com/gtag/js?id=UA-110119275-1"></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag(){dataLayer.push(arguments);}
			gtag('js', new Date());

			gtag('config', 'UA-110119275-1');
		</script>
		
		<!-- HOTJAR -->
		
		<!-- Hotjar Tracking Code for www.hugomoutinho.com -->
		<script>
				(function(h,o,t,j,a,r){
						h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
						h._hjSettings={hjid:701080,hjsv:6};
						a=o.getElementsByTagName('head')[0];
						r=o.createElement('script');r.async=1;
						r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
						a.appendChild(r);
				})(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
		</script>

		<?php wp_head(); ?>
	</head>

<body <?php body_class(); ?>>

<?php if ( function_exists( 'gtm4wp_the_gtm_tag' ) ) { gtm4wp_the_gtm_tag(); } ?>

<nav>
	<a style="opacity: 1!important;" id="my-logo" href="<?php bloginfo('url')?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/hm-logo.svg" alt=""></a>
	<span class="mobile-button"></span>
	<div id="menu-parent">
		<?php
				$args = array(
						'menu' => 'principal',
						'container' => false
				);
				wp_nav_menu( $args );
		?>
	</div>
</nav>
