<?php
// Template Name: Home
?>

<!-- INCLUDE HEADER -->

<?php get_header();?>

<div class="main">

<!-- FOLD -->
<section class="front-portfolio">
	<div class="container">
		<h2>Hi, my name is Hugo.</h2>
		<h1>I help businesses, brands and people communicate the best version of their ideas.</h1>
		<div id="scroll-down" class="twelve columns">
			<img src="<?php echo get_stylesheet_directory_uri(); ?>/img/arrow_down.svg" alt="">
		</div>
	</div>
</section>

<!-- WORK 1 -->

<section class="sec-portfolio">
	<div class="container flex-parent">
		<div class="flex-child-1">
			<img id='voidbee-svg' src="<?php echo get_stylesheet_directory_uri(); ?>/img/moon.svg" alt="Voidbee - Social Network for Game Developers">
		</div>
		<div class="flex-child-1">
			<h2>Voidbee</h2>
			<h4>Social Network for Game Developers</h4>
			<p class="p-small">Branding | UX&UI</p>
			<a target="_blank" href="https://www.behance.net/gallery/41677275/Voidbee-Social-Network-for-Game-Developers" id="btn-voidbee" class="button">View Project</a></div>
	</div>
</section>

<!-- WORK 2 -->

<section class="sec-portfolio">
	<div class="container flex-parent-reverse">
		<div class="flex-child-1">
			<img id="aal-png" src="<?php echo get_stylesheet_directory_uri(); ?>/img/aal-min.png" alt="Rock Band Landing Page">
		</div>
		<div  class="flex-child-1">
			<h2>Landing Page Template</h2>
			<h4>Rock Band Landing Page</h4>
			<p class="p-small">UX&UI</p>
			<a target="_blank"  href="https://www.behance.net/gallery/56114895/Rock-Band-Landing-Page" id="btn-aal" class="button">View Project</a></div> 
	</div>
</section>



<!-- WORK 3: BEHANCE -->

<section class="sec-portfolio">
	<div class="container flex-parent">
		<div class="flex-child-1 align-center">
			<p class="p-large align-center">Check out my other projects on</p>
			<a target="_blank" class="a-link align-center" href="https://www.behance.net/hugomoutinho"><h3>Behance</h3></a>
			<div class="footer">
					<p class="p-small align-center">website developed by <a class="a-link" href="http://www.hugomoutinho.com">Hugo Moutinho</a></p>
			</div>
		</div> 
	</div>
</section>

</div>
<!-- INCLUDE FOOTER -->


<?php get_footer(); ?>