		<!-- SCRIPT -->

	<script src="<?php echo get_template_directory_uri(); ?>/js/libs/jquery-3.2.1.min.js"></script>
	
	<?php
	
	if (is_single()) {
		echo ' 	
		<section class="container">
			<div class=" subscribe-blog">
				<div class="six columns">
					<h1>Get more insights.</h1>
					<p class="p-regular">Straight to your inbox.</p>
				</div>
				<div class="six columns">
					<form action="" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
						<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL" placeholder="your best email">
						<input type="text" value="" name="FNAME" class="" id="mce-FNAME" placeholder="your first name">
						<div id="mce-responses" class="clear">
							<div class="response" id="mce-error-response" style="display:none"></div>
							<div class="response" id="mce-success-response" style="display:none"></div>
						</div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
						<div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_4cd216682ded9971ddd0f892e_097288f886" tabindex="-1" value=""><br></div>
						<div class="clear"><input id="btn-subscribe" class="button" type="submit" value="Subscribe me now" name="subscribe" id="mc-embedded-subscribe" class="button"><br></div>
					</form>
						<script type="text/javascript" src="//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js"></script><script type="text/javascript">(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]="EMAIL";ftypes[0]="email";fnames[1]="FNAME";ftypes[1]="text";}(jQuery));var $mcj = jQuery.noConflict(true);</script>
				</div>
			</div>
		</section>';
	} else {
		echo '';
	}
	
	if (is_front_page()) {
		$templateDirectory = get_template_directory_uri();
		echo "<script src='" . $templateDirectory . "/js/main.js'></script>";
	} else {
		echo '';
	}	

	?>

	<script>
	//Mobile Menu
	$('.mobile-button').click(function(){
	$(this).toggleClass('active');
	$('#menu-parent').toggleClass('active');
	})	
		
	</script>

	<div class="footer" style="<?php if (is_front_page()) {echo 'display:none;';}?>">
				<p class="p-small align-center">template developed by <a class="a-link" href="http://www.hugomoutinho.com">Hugo Moutinho</a></p>
	</div>
    <?php wp_footer(); ?>
   
  </body>
</html>
